
/* 
 Authors
 Martin Schlather, schlather@math.uni-mannheim.de

 Collection of system specific auxiliary functions

 Copyright (C) 2001 -- 2017 Martin Schlather, 

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

//#include <Rmath.h>
//#include <unistd.h>
#include "RandomFieldsUtils.h"
//#include "win_linux_aux.h"
#include "General_utils.h"
#include "intrinsics.h"
//#include "Solve.h"
//#include "own.h"


SEXP getChar() {
  ERR("does not work");
#ifdef WIN32
  ERR("input limitations on windows");
#endif
#define maxGetChar 255
  //typedef char intchar[sizeof(int) / sizeof(char)];
  //typedef char intchar[sizeof(int) / sizeof(char)];
  SEXP str;
  int //g,
    i = -1;
  char // c, *t = NULL,
    *s = NULL
    ;
  s = (char*) MALLOC(sizeof(char) * maxGetChar);
  // initscr();
  //  fflush(stdin);
  //  nocbreak();
  while (++i < maxGetChar) {
    // g = getchar();       
    //s[i] = ((intchar*) &g)[0][0];
    // g = scanf("%c\n", s); s[1] = '\0'; break;
    //t = fgets(s, 2, stdin); break;
    //    s[i] = getch();
    //fflush(stdin);
    if (false) {
      s[i+1] = '\0';
      // printf("%d i=%d  '%c' '%c' '%c' '%c' '%c'\n", g, i,  s[i],
      // ((intchar*) &g)[0][0],
      //  ((intchar*) &g)[0][1],
      // ((intchar*) &g)[0][2],
      // ((intchar*) &g)[0][3]
      // );
    }
    if (s[i] == '\n') {
      s[i] = '\0';
      break;
    }
  }
  //endwin();
//printf(">%s<\n", s);
  PROTECT(str=allocVector(STRSXP, 1));
  SET_STRING_ELT(str, 0, mkChar(s));  
  UNPROTECT(1);
  FREE(s);
  return str;
}

void colMaxsI(double *M, int r, int c, double *ans) {
#ifdef DO_PARALLEL
#pragma omp parallel for
#endif  
  for (int i=0; i<c; i++) {
    //  printf("i=%d\n", i);
    double dummy,
      *m = M + r * i;
    //#ifdef AVX
#if defined SSE2
    double *start = algn(m),
      *end = m + r;
    uintptr_t End = (uintptr_t) (end - doubles);
    if ((uintptr_t) start < End) {
      Double * ALIGNED m0 = (Double*) start,
	Dummy = (Double) LOAD((BlockType*) m0);
      for (m0++ ; (uintptr_t) m0 < End; m0++) {
	//printf("%ld\n", (uintptr_t) m0);
	Dummy = MAXDOUBLE(Dummy, (Double) LOAD((BlockType*) m0));
      }
      double *d = (double *) &Dummy;
      dummy = d[0];
      dummy = dummy < d[1] ? d[1] : dummy;
#if defined AVX
      dummy = dummy < d[2] ? d[2] : dummy;
      dummy = dummy < d[3] ? d[3] : dummy;   
      //     printf("%f %f %f %f dummy=%f\n", d[0], d[1], d[2], d[3], dummy);
#else      
      //  printf("%f %f \n", d[0], d[1]);
#endif
      for ( ; m<start; m++) dummy = dummy > *m ? dummy : *m;
      m = (double *) m0;
      for ( ; m<end; m++) dummy = dummy > *m ? dummy : *m;
    } else {
      dummy = m[0];    
      for (int j=1; j<r; j++) dummy = dummy > m[j] ? dummy : m[j];
    }
#else
    dummy = m[0];    
    for (int j=1; j<r; j++) dummy = dummy > m[j] ? dummy : m[j];
#endif    
    ans[i] = dummy;
  }
}

SEXP colMaxs(SEXP M) {
  int
    r = nrows(M),
    c = ncols(M);
  if (r == 0) return R_NilValue;
  SEXP Ans;
  PROTECT(Ans = allocVector(REALSXP, c));
  colMaxsI(REAL(M), r, c, REAL(Ans));
  UNPROTECT(1);
  return Ans;
}


SEXP rowMeansX(SEXP M, SEXP Factor) {
  int
    r = nrows(M),
    c = ncols(M);
  if (r == 0 || c == 0) return R_NilValue;
  if (length(Factor) != c)
    ERR("Length of 'factor' must equal number of columns of 'x'.");
  SEXP Ans;
  PROTECT(Ans = allocVector(REALSXP, r));
  double *ans = REAL(Ans),
    *factor = REAL(Factor),
    *m = REAL(M);
  for (int j=0; j<r; j++) ans[j] = 0.0;
  for (int i=0; i<c; i++, m+=r) {
    double dummy = factor[i]; // load1(factor); MULTDOUBLE
    for (int j=0; j<r; j++) ans[j] += m[j] * dummy;
  }
  double invc = 1.0 / (double) c;
  for (int j=0; j<r; j++) ans[j] *= invc;
  UNPROTECT(1);
  return Ans;
}

