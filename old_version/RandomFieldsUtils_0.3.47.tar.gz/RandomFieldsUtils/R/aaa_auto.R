# This file has been created automatically by 'rfGenerateConstants'


 ## from  src/AutoRandomFieldsUtils.h

 MAXUNITS 	<- as.integer(4)
 MAXCHAR 	<- as.integer(18)
 RFOPTIONS 	<- "RFoptions"

 PIVOT_UNDEFINED 	<- as.integer(NA)
 PIVOT_NONE 	<- as.integer(0)
 PIVOT_AUTO 	<- as.integer(1)
 PIVOT_DO 	<- as.integer(2)
 PIVOT_IDX 	<- as.integer(3)
 PIVOT_IDXBACK 	<- as.integer(4)
 PIVOTSPARSE_MMD 	<- as.integer(1)
 PIVOTSPARSE_RCM 	<- as.integer(2)



