
.onLoad <- function(lib, pkg) {
  .Call("attachRFoptionsUtils")
}

.onAttach <- function (lib, pkg) {
#   packageStartupMessage();
}

.onDetach <- function(lib) {
# .Call("detachRFoptionsUtils")
}

.onUnload <- function(lib, pkg){
  .Call("detachRFoptionsUtils")
}
