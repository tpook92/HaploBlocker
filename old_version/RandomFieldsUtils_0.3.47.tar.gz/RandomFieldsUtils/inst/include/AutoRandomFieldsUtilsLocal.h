#ifndef auto_rfutils_local_h
#define auto_rfutils_local_h 1

#define PIVOT_NONE 0  
#define PIVOT_AUTO 1  
#define PIVOT_DO 2    
#define PIVOT_IDX 3    // IDX is not returned by RFoptions
#define PIVOT_IDXBACK 4  // (last) as PIVOT_IDX, but RFoptions returns IDX 
#define PIVOT_UNDEFINED 5
#define PIVOT_LAST PIVOT_UNDEFINED
#define PIVOTSPARSE_MMD 1 // for spam
#define PIVOTSPARSE_RCM 2 // for spam


#endif
