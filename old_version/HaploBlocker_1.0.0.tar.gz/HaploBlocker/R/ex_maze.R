#' @name ex_maze
#' @title Example dataset MAZE
#' @description A dataset of 313 DH-lines of the first chromosome of maize
#' @usage ex_maze
#' @source TUM Weihenstephan
#' @author Torsten Pook \email{torsten.pook@uni-goettingen.de}
NULL
