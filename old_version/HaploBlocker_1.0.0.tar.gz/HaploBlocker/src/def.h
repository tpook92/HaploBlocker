/*
 Authors 
 Martin Schlather, schlather@math.uni-mannheim.de


 Copyright (C) 2015 -- 2017  Martin Schlather

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.  
*/



#ifndef RFutils_def_h
#define RFutils_def_h 1

#ifdef LOG
#undef LOG
#endif
#define LOG std::log

#ifdef Mod
#undef Mod
#endif
#define Mod(ZZ, modulus) ((ZZ) - FLOOR((ZZ) / (modulus)) * (modulus))

#ifdef SIGN
#undef SIGN
#endif
#define SIGN(X) sign((double) X)

#ifdef SQRT
#undef SQRT
#endif
#define SQRT(X) std::sqrt((double) X)


#ifdef FABS
#undef FABS
#endif
#define FABS(X) std::fabs((double) X) // keine Klammern um X! 


#ifdef POW
#undef POW
#endif
#define POW(X, Y) R_pow((double) X, (double) Y) // keine Klammern um X!


#ifdef CEIL
#undef CEIL
#endif
#define CEIL(X) std::ceil((double) X) // keine Klammern um X!


#ifdef FLOOR
#undef FLOOR
#endif
#define FLOOR std::floor



#ifdef MAX
#undef MAX
#endif
#define MAX(A,B) ((A) > (B) ? (A) : (B))


#ifdef MIN
#undef MIN
#endif
#define MIN(A,B) ((A) < (B) ? (A) : (B))




#ifdef STRLEN
#undef STRLEN
#endif
#define STRLEN std::strlen


#ifdef STRCPY
#undef STRCPY
#endif
#define STRCPY(A, B) std::strcpy(A, B)



#ifdef STRNCPY
#undef STRNCPY
#endif
#define STRNCPY(A, B) std::strcpy(A, B)


#ifdef STRNCMP
#undef STRNCMP
#endif
#define STRNCMP(A, B, C) std::strncmp(A, B, C)

#ifdef LOGI
#undef LOGI
#endif
#define LOGI Logical(el, name, 0)


/*
#ifdef 
#define

*/
#endif


